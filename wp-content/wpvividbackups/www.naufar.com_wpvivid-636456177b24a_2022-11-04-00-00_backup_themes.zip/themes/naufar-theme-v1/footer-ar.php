<div class="footer">
  <div class="container">
    <div class="row">
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <ul>
          <li><a href="/ar/مهمتنا/">معلومات عنا</a></li>
         
          <li><a href="https://webmail.naufar.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fwebmail.naufar.com%2fowa">موارد الموظفين</a></li>
          <li><a href="/ar/news-arabic/">وسائل الإعلام</a></li>
			<li><a href="/ar/contact-2/">اتصل بنا</a></li>
          
	
        </ul>
       <div class="sociallink"><a href="https://www.facebook.com/NaufarQatar/" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/social1.png" width="34" height="35" alt=""></a> <a href="https://www.instagram.com/naufarqatar/?hl=en" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/social2.png" width="34" height="35" alt=""></a> <a href="https://www.twitter.com/naufarQatar" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/social3.png" width="34" height="35" alt=""></a> <a href="https://www.youtube.com/channel/UCuIW67jrpA1pjrmevFbuN9w" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/social4.png" width="34" height="35" alt=""></a>  <a href="https://www.linkedin.com/company/naufar-wellness-and-recovery/" target="_blank"><img src="/wp-content/uploads/2022/05/social5.png" width="34" height="35" alt=""></a></div>
        <div class="copyright">حقوق النشر ©2022 بواسطة نوفر. كل الحقوق محفوظة.</div>
      </div>
    </div>
  </div>
</div>

<?php wp_footer(); ?>
</body>
</html>